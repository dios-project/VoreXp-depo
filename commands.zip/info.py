import os


def command(args):
  print(f"""
Kullanıcı: {vore_config["runuser"]} 
Platform: {vore_config["platform"]}
""")