import os
def command(args):
  for x in range(len(os.listdir())):
    print(os.listdir()[x])