import os
import sys

def command(args):
  for i in range(len(os.listdir(vore_config["commandspath"]))):

    if os.path.isfile(vore_config["commandspath"]+os.listdir(vore_config["commandspath"])[i]):
      print(os.listdir(vore_config["commandspath"])[i])
    else:
      pass