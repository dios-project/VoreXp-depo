import os
import sys
info="Python Command Executer"

def command(args):
  try:
    exec_text=""
    for i in range(len(args[0::])):
      if i == 0:
        exec_text+=args[0::][i]
      else:
        exec_text+=" "+args[0::][i]
    exec(exec_text)
  except IndexError:
    print("ArgumentError: Pexec, argument code required")
  except Exception as e:
    print(e)