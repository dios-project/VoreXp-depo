import datetime
info="shows the current time"
def command(args):
  print(datetime.datetime.now())
