import os
import sys

def command(args):
  if args[0] == "content":
    try:
      with open(args[1],"r+",encoding="utf8") as f:
        print(f.read())
    except FileNotFoundError:
      print(f"file '{args[1]}' not found.")
    except IndexError:
      print("Argument Error")
  elif args[0] == "edit":
    with open(args[1],"w",encoding="utf8") as f:
      lines = []
      while True:
        line = input()
        if line:
            lines.append(line)
        else:
            break
        text = '\n'.join(lines)
        f.seek(0)
        f.truncate()
        f.write(text)