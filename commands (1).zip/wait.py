import time
info="makes the console wait"
def command(args):
  try:
    wait=int(args[1])
    time.sleep(wait)
  except ValueError:
    print("Geçersiz girdi")
  except IndexError:
    print("Argüman <saniye> gerekli")