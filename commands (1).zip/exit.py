import  sys
info="logs out of vorexp"
def command(args):
  sys.exit()