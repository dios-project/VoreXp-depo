import os
info="Current Current dir path"
def command(args):
  print(os.getcwd())