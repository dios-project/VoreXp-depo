import os
info="creates a file/files"
def command(args):
  for i in range(len(args)):
    with open(args[i],"w") as f: pass