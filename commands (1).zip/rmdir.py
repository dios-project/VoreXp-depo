import os

def command(args):
  try:
    os.rmdir(str(args[0]))
  except FileNotFoundError:
    print(f"Klasör '{args[0]}' bulunamadı")