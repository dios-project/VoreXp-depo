import os
import sys

info="Help command For VoreXp"
def command(args):
  print("Command Count:"+str(len(os.listdir(vore_config["commandspath"]))))
  for i in range(len(os.listdir(vore_config["commandspath"]))):
    if os.path.isfile(vore_config["commandspath"]+os.listdir(vore_config["commandspath"])[i]):
      b=__import__(os.listdir(vore_config["commandspath"])[i].split(".")[0])
      try:
        print(os.listdir(vore_config["commandspath"])[i]+" :"+b.info)
      except AttributeError:
        print(os.listdir(vore_config["commandspath"])[i])
    else:
      pass