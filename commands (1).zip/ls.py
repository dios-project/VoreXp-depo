import os
info="lists Directory"
def command(args):
  if len(args) == 1:
    if os.path.isdir(args[0]):
      for x in range(len(os.listdir(args[0]))):
        print(os.listdir(args[0])[x])
    else:
      print(f"Directory Not Found")
  else:
    for x in range(len(os.listdir())):
      print(os.listdir()[x])