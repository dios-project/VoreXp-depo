import shutil
info="Removes Cache dir"
def command(args):

  shutil.rmtree(vore_config["commandspath"]+"/__pycache__")