import os
import sys

def command(args):
  if args[0] == "new":
    sys.path.append(args[1])
  elif args[0] == "show":
    for i in range(len(sys.path)):
      print(sys.path[i])
  else:
    print("Invalid Argument")