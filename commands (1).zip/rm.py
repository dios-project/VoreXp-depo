import os

def command(args):
  try:
    os.remove(str(args[0]))
  except FileNotFoundError:
    print(f"dosya '{args[0]}' bulunamadı")