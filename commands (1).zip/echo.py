info="Echo"
def command(args):
  string=""
  for i in range(len(args)):
    if i == 0:
      string+=args[i]
    else:
      string+=" "+args[i]
  print(string)