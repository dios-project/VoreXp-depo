import threading
import time
info="Alarm"


def command(args):
  try:
    wait=float(args[0])
  except ValueError as e:
    print(e)
    print("Geçersiz Girdi")
  except IndexError:
    print("Argüman Hatası: argüman <wait> gerekli")

  try:
    message=args[1]
  except IndexError:
    print("Argüman Hatası:argüman <...> <message> gerekli")
  def f():
    print("\n"+message)
  threading.Timer(wait,f).start()